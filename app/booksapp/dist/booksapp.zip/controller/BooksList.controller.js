sap.ui.define(["sap/ui/core/mvc/Controller"],o=>{"use strict";return o.extend("booksapp.controller.BooksList",{onInit(){}})});
//# sourceMappingURL=BooksList.controller.js.map