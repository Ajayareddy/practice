sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{uploadImageMethod:function(s){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=ImageFileHandler.js.map