sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("booksapp.controller.Home",{onInit:function(){}})});
//# sourceMappingURL=Home.controller.js.map