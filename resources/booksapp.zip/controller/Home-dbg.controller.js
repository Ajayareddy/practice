sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";

    return Controller.extend("booksapp.controller.Home", {
        onInit: function () {
            // you can add logic here later if needed
        }
    });
});
